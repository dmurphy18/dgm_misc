========================
CherryPy Base Test Class
========================

.. automodule:: salttesting.cherrypytest.base
    :members:
