.. automodule:: salttesting.runtests

.. autoclass:: salttesting.runtests.TestDaemon
