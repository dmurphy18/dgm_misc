"""
aid package

helper and utility modules
"""
#print("\nPackage at {0}".format( __path__[0]))
