# for backwards compatibility. In future import from ..aid.osetting

from ..aid.osetting import oset
