.. automodule:: salttesting.parser.cover
    :members:
