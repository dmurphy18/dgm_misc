.. automodule:: salttesting.mock
    :members:
