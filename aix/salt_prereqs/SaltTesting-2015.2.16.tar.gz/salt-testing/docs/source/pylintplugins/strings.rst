.. automodule:: salttesting.pylintplugins.strings
    :members:
